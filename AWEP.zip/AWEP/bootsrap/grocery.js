function add(){
    let add=document.querySelector('.additems').value;
    let cloneadd=document.querySelector('.commentbox').cloneNode('true');
     cloneadd.style.visibility='visible';
    if(add===''){
        alert('Please add items in the list.')
    }else{
    cloneadd.children[0].innerHTML=add.toUpperCase();
    let commentsDiv=document.querySelector('.box');
    commentsDiv.insertBefore(cloneadd,commentsDiv.firstChild);
    document.querySelector('.additems').value='';
    }

};
function deleteItems(items){
     items.parentElement.remove();
};

let clearItems=()=>{
//     let itemsList=Number(document.querySelector('.commentbox').children[0].innerHTML);
 
//    if( typeof itemsList==="number" || typeof itemsList==='NaN'){
//        return;

//    }else{
      
    document.querySelector('.box').innerHTML='';
  // }
   
};
