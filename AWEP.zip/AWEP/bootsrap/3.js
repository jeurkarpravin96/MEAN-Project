
let like=(btnelement)=>{
      let likecount= parseInt(btnelement.children[0].innerHTML);
      likecount++;
      btnelement.children[0].innerHTML=likecount;
    };


function comment(btn){
  let inputvalue=btn.parentElement.parentElement.children[1].children[0].value;
  let newel=btn.parentElement.parentElement.parentElement.children[2].children[0].children[0].cloneNode(true);
  newel.style.visibility='visible';
    if(inputvalue===''){
      confirm('Please enter comment..')
    }else{
     newel.children[0].innerHTML=inputvalue;
     let divstorebox=btn.parentElement.parentElement.parentElement.children[2].children[0];
     divstorebox.insertBefore(newel,divstorebox.firstChild);
    btn.parentElement.parentElement.children[1].children[0].value='';

    }
};

function del(btn){
     btn.parentElement.parentElement.remove();
};
