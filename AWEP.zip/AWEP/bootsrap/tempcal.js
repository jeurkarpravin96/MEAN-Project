function fahrenheit(fahrenheit){
 let fahrenheitNumber=parseFloat(fahrenheit);
  document.querySelector('.celsius').value=(fahrenheitNumber-32)*5/9;
  document.querySelector('.kelvin').value=fahrenheitNumber+255.372;
};
function celsius(celsius){
    let celsiusNumber=parseInt(celsius);
    document.querySelector('.fahrenheit').value= celsiusNumber*(9/5)+32;
    document.querySelector('.kelvin').value=celsiusNumber+273.15;
  };
  
function kelvin(kelvin){
    let kelvinNumber=parseInt(kelvin);
    document.querySelector('.fahrenheit').value=kelvinNumber-459.67;
    document.querySelector('.celsius').value=kelvinNumber-273.15;
};
