
let student=[
    {
        id:001,
        firstname:'pravin',
        lastname:'jeurkar'
    },
    {
        id:002,
        firstname:'harshit',
        lastname:'jain'
    },
    {
        id:003,
        firstname:'Ashish',
        lastname:'Sharma',
    },
    {
        id:004,
        firstname:'Rahul',
        lastname:'Jadhav',
    },
    {
        id:005,
        firstname:'Tushar',
        lastname:'More',
    },
    {
        id:006,
        firstname:'Rajat',
        lastname:'Nikhate',
    },
    {
        id:007,
        firstname:'Rohan',
        lastname:'Kolhe',
    },
    {    
        id:08,
        firstname:'Ravi',
        lastname:'Pilgar',
    }
]


window.addEventListener('load',()=>{
    
    const parent=document.querySelector('#parentblock');
    for(i=0;i<20;i++){
    let list=student[i];
    let cloneblock=parent.children[0].cloneNode(true);
    cloneblock.style.display = "flex";
    cloneblock.children[0].innerHTML=list.firstname.toUpperCase()+' '+list.lastname.toUpperCase();
    parent.insertBefore(cloneblock,parent.firstChild);

  }
});