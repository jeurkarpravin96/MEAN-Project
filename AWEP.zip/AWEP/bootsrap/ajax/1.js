const pcb=document.querySelector('#parentblock');
console.log(pcb);

window.addEventListener("load",()=>{

    
    for(i=0;i<10;i++){
        const pcb = document.querySelector('#parentblock');
        let cloneblock=pcb.children[0].cloneNode(true);
         pcb.insertBefore(cloneblock,pcb.firstChild);
    }
})