

let likes=(likes)=>{
  let likescount= likes.children[0].innerHTML;
  likescount++;
  likes.children[0].innerHTML=likescount;
};

let comments=(comments)=>{
   //access input
   let inputvalue=comments.parentElement.parentElement.children[1].children[0].value;
   console.log(inputvalue);

   //clone
  if(inputvalue===''){
      
        comments.parentElement.parentElement.parentElement.children[2].children[0].children[0].innerHTML='Please enter comment ..';
  }else{
    let parentcommentbox=comments.parentElement.parentElement.parentElement.children[2].children[0];
    let newelement=comments.parentElement.parentElement.parentElement.children[2].children[0].children[0].cloneNode(true);
    newelement.style.visibility='visible'
    newelement.children[0].innerHTML=inputvalue;
    parentcommentbox.insertBefore(newelement,parentcommentbox.firstChild);
 
    comments.parentElement.parentElement.children[1].children[0].value='';
  }

};


let deletecomment=(deletecomment)=>{
            deletecomment.parentElement.parentElement.remove();
};


let list=[
    {
        img:'<img src="https://picsum.photos/id/124/410/200"></img>',
    },
    {
       
        img:'<img src="https://picsum.photos/id/774/410/200"></img>',
    },
    {
        img:'<img src="https://picsum.photos/id/334/410/200"></img>',
    },
    {
       
        img:'<img src="https://picsum.photos/id/497/410/200"></img>',
    },
    {
        img:'<img src="https://picsum.photos/id/5/410/200"></img>',
    },
    {
       
        img:'<img src="https://picsum.photos/id/84/410/200"></img>',
    },
    {
        img:'<img src="https://picsum.photos/id/836/410/200"></img>',
    },
    {
       
        img:'<img src="https://picsum.photos/id/387/410/200"></img>',
    },
    {
        img:'<img src="https://picsum.photos/id/123/410/200"></img>',
    },
    {
       
        img:'<img src="https://picsum.photos/id/111/410/200"></img>',
    },
    {
       
        img:'<img src="https://picsum.photos/id/387/410/200"></img>',
    },
    {
        img:'<img src="https://picsum.photos/id/123/410/200"></img>',
    },
    {
       
        img:'<img src="https://picsum.photos/id/111/410/200"></img>',
    },

]


window.addEventListener('load',()=>{
    const parentbox=document.querySelector('#parent');
  
    for(i=0;i<list.length;i++){
       let post=list[i];
     let newbox= parentbox.children[0].cloneNode(true);
      newbox.style.visibility='visible';
     newbox.children[0].children[0].innerHTML=post.img;
      parentbox.insertBefore(newbox,parentbox.firstChild);
       
    }
})