let list=[
    {
        img:'<img src="https://picsum.photos/id/124/369/200"></img>',
    },
    {
       
        img:'<img src="https://picsum.photos/id/774/369/200"></img>',
    },
    {
        img:'<img src="https://picsum.photos/id/334/369/200"></img>',
    },
    {
       
        img:'<img src="https://picsum.photos/id/497/369/200"></img>',
    },
    {
        img:'<img src="https://picsum.photos/id/5/369/200"></img>',
    },
    {
       
        img:'<img src="https://picsum.photos/id/84/369/200"></img>',
    },
    {
        img:'<img src="https://picsum.photos/id/836/369/200"></img>',
    },
    {
       
        img:'<img src="https://picsum.photos/id/387/369/200"></img>',
    },
    {
        img:'<img src="https://picsum.photos/id/123/369/200"></img>',
    },
    {
       
        img:'<img src="https://picsum.photos/id/111/369/200"></img>',
    },
    {
       
        img:'<img src="https://picsum.photos/id/387/369/200"></img>',
    },
    {
        img:'<img src="https://picsum.photos/id/123/369/200"></img>',
    },
    {
       
        img:'<img src="https://picsum.photos/id/111/369/200"></img>',
    },

]


    window.addEventListener('load',()=>{
        console.log('work')
        for(i=0;i<list.length;i++){
           let itemslist=list[i];
            let box=document.querySelector('#box');
            let newelement=box.children[0].cloneNode(true);
            newelement.style.visibility='visible';
            newelement.children[0].innerHTML=itemslist.img;
            box.insertBefore(newelement,box.firstChild)
        }
    });

