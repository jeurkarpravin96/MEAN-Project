const dbadd=require('./db.add');
const dbdel=require('./db.delete');
const dbupdate=require('./db.update');
const dbmodify=require('./db.modify')
//dbadd.addData();

// dbadd.addDatawithparam('pravin','jeurkar','1234567');

// let user={
//     fname:'nilesh',
//     lname:'jeurkar',
//     mobileNo:'9011769423'
// }


 dbadd.addDatawithjson(dbadd.user);


let input={
    id:'1',
    fname:'pravin'
}

// dbdel.deletedatajson(user);


let data={
    fname:'pravin',
    mobileNo:'7249726920'
};

//dbupdate.dbupdatedata(data);


let userdata={
     column:'fname',
};

//dbmodify.dbmodifydata(userdata);