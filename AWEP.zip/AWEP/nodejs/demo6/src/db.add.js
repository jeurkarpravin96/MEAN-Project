const Promise=require('bluebird');
const mysql=require('mysql');
const config=require('./config');
const Connection = require('mysql/lib/Connection');

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

//hard coaded

let addData=async()=>{
    const connection= mysql.createConnection(config.DB_Config);
   await connection.connectAsync();
    
    let sql='insert into user (fname,lname,mobileNo) values(?,?,?)';

    let data=await connection.queryAsync(sql,['pravin','jeurkar','7249726920']);

    await connection.endAsync();
    return data;
};



/**
 * with param
 * @param {*} fname 
 * @param {*} lname 
 * @param {*} mobileNo 
 */ 

let addDatawithparam= async(fname,lname,mobileNo)=>{
     const connection= mysql.createConnection(config.DB_Config);

      await connection.connectAsync();
        
       //logic
      let sql='insert into user (fname,lname,mobileNo) values(?,?,?)'
      let data=await  connection.queryAsync(sql,[fname,lname,mobileNo]);

      await connection.endAsync();
      return data;
};

/**
 * with json
 * @param {*} user 
 */


let user={
    fname:'nilesh',
    lname:'jeurkar',
    mobileNo:'9011769423'
}


let addDatawithjson=async(user)=>{
    const connection=  mysql.createConnection(config.DB_Config);

   await connection.connectAsync();
   //logic
   let sql='insert into user(fname,lname,mobileNo) values(?,?,?)';
   const data =await connection.queryAsync(sql,[user.fname,user.lname,user.mobileNo]);   

   await connection.endAsync();
   return data;
};



module.exports={addData ,addDatawithparam,addDatawithjson,user};