let mod=require('./1');
 
console.log('hello world',mod);