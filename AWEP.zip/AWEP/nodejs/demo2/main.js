let mod=require('./my.module');


let addition= new mod('pravin',1,2,3,4,5,6,'jeurkar');

let p=addition.getdetails();
console.log(p);