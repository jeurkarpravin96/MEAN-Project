const fs=require('fs');
 
let demo=()=>{
  const path='file.md';
  fs.readFile(path,{encoding:'utf-8'},(err,data)=>{ 
      console.log('1',data);  
   });

  const path1='file1.md';
  fs.readFile(path1,{encoding:'utf-8'},(err,data)=>{
  console.log('2',data);
  });

  const path2='file2.md';
  fs.readFile(path2,{encoding:'utf-8'},(err,data)=>{
  console.log('3',data);
   });

}
