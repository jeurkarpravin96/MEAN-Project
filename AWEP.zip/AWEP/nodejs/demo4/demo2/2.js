const fs=require('fs');
const filepath='./demo1/file.md';
const filepath1='./demo1/file1.md';
const filepath2='./demo1/file2.md';
let demo=()=>{
    let data1=fs.readFileSync(filepath1,{encoding:'utf-8'});
    console.log('2',data1);
    let data2=fs.readFileSync(filepath2,{encoding:'utf-8'});
    console.log('3',data2);
    let data=fs.readFileSync(filepath,{encoding:'utf-8'});
    console.log('1',data);
};
demo();