const fs=require('fs');
const filepath='./demo1/file.md';

let demo=()=>{
    fs.readFile(filepath,{encoding:'utf-8'},(err,data)=>{
             if(err){
                 console.log('some problem encoaded while reading file',err);
             }else{
                 console.log(data);
             }
    })
}

demo();