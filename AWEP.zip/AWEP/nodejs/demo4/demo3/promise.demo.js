const fs=require('fs'); //fs is internal module  
//require function is the easiest way to include modules(local,internal or external modules) that 
//exist in separate files. The basic functionality of require is that it reads a 
//JavaScript file, executes the file, and then proceeds to return the exports object

const promise=require('bluebird') //bluebird is external modules
//promisification :: convert all callback function or method to return promise
promise.promisifyAll(fs);

//you can handle the promise with the help of then()  when run successffully and 
//catch() to catch error

let demo=()=>{
    //1st file reading
    const filepath='/home/pravin/awep/AWEP/nodejs/demo4/demo1/file1.md';
    const datapromise=  fs.readFileAsync(filepath,{encoding:'utf-8'})
    .then((data)=>{console.log(data)}).catch((err)=>{console.log(err)});

    //2nd file reading
     const filepath1='/home/pravin/awep/AWEP/nodejs/demo4/demo1/file2.md';
     const data2= fs.readFileAsync(filepath1,{encoding:'utf-8'}).then((data)=>{console.log(data)})
     .catch((err)=>{console.log(err)});

};

demo();