const DB_Config={
    host:'localhost',
    user:'root',
    password:'Pravin@123',
    database:'mydb'
};

module.exports={DB_Config}