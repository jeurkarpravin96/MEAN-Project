const Promise=require('bluebird');
const mysql=require('mysql');
const config=require('./config');


Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

let readAlldata=async()=>{
    const Connection= mysql.createConnection(config.DB_Config);

    await Connection.connectAsync();
  
    let sql='select * from user';
    const data=await  Connection.queryAsync(sql);
    console.log(data);
    await Connection.endAsync();

    return data;
}
module.exports={readAlldata};
