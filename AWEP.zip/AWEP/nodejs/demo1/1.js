let add=(a,b)=>{
    return a+b;
};

let sub=(a,b)=>{
    return a-b;

};

let multi=(a,b)=>{
    return a*b;
};

let div=(a,b)=>{
    return a/b;
};


module.exports={
    add,
    multi,
    sub,
    div
};