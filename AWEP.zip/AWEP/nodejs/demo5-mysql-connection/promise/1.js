const { resolve, reject } = require("bluebird");

let cal=(x,y)=>{
   console.log('x = '+x+'  '+'y = '+y);
   P(x,y).then((data)=>{console.log(data)}).catch((err)=>{console.log(err)});
};

//internal working of promise
let P=(x,y)=>{
    return new Promise((resolve,reject)=>{
        if(x+y>0){
               resolve(x+y);
        }else{
            reject('sum is less than zero');
        }
    })
};

cal(-3,2);