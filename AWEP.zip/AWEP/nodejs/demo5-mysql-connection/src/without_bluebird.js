
const mysql=require('mysql');
const DB_Connection ={
        host:'localhost',
        user:'root',
        password:'Pravin@123',
        database:'mydb'
    }
 let getdetail=(sql)=>{
    return new Promise((resolve,reject)=>{
        connection.query(sql,(err,result)=>{
            if (err){
                resolve(err)
            }
            else{
                reject(result)
        }
        })
    })
};

let readdata= async()=>{
    const connection=mysql.createConnection(DB_Connection);

    await connection.connect();
    const sql='select * from user';
    let data=await getdetail(sql);
    console.log(data)
    await connection.endAsync();
    return data;
};
readdata();


