
const Promise=require("bluebird");
const mysql=require('mysql');
const mod=require('./main');

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

let readDataFromDatabase= async()=>{      
    const connection=mysql.createConnection(mod.DB_Connection);
    //connection start
   await connection.connectAsync();
   //logic  
    let sql='SELECT ?? FROM user where id=?';
    let data=await connection.queryAsync(sql,['fname','1']);
     console.log('connected')
     console.log(data);
   //connection end
   await connection.endAsync();
   return data;
}

readDataFromDatabase();
