const Promise=require('bluebird');
const mysql=require('mysql');
const config=require('./config');


Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);


let addData=async(input)=>{
const connection=mysql.createConnection(config.DB_Config);

  await connection.connectAsync();
   let sql='insert into user (username,mobileNo,password,email) values(?,?,?,?)';
  await connection.queryAsync(sql,[
      input.username,
      input.password,
      input.email,
      input.mobile
  ]);
  await connection.endAsync();
};

module.exports={addData};