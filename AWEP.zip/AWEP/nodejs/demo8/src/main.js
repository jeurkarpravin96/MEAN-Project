const express=require('express');
const add=require('./db.add.user');
const app=express();


//http://localhost:3100/adduser?username=pravin&password=123&email=p@gmail.com&mmobile=0987655;

app.get('/adduser',(req,res)=>{
    try{
       let user={msg:'success'};
       res.json(user);
     }catch(err){
        let user={msg:'fails'};
        res.json(user);
    }
})
app.listen(3300);