function like(likes){
    let count=likes.children[0].innerHTML;
    count++;
    likes.children[0].innerHTML=count;  
};
function comment(){
    let inputvalue=document.querySelector('#text').value;
    let clonebox=document.querySelector('.commentbox').cloneNode(true);
    clonebox.style.visibility='visible'
   if(inputvalue==''){
       confirm('please enter comment..');
   }else{
    clonebox.children[0].innerHTML=inputvalue;
    let divbox=document.querySelector('.box');
    divbox.insertBefore(clonebox,divbox.firstChild);
    document.querySelector('#text').value='';
   }
};
function del(del){
    del.parentElement.remove();
}