let num = 100;

function sum(num) {
    num = 1000;
    console.log(100 + num);
}
sum(num)