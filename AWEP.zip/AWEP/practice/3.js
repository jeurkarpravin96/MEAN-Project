
function sub(){
      var inputvalue=document.querySelector('.text').value;
      var newbox=document.querySelector('#commentbox').cloneNode(true);
         newbox.style.visibility='visible';

      newbox.children[0].children[0].innerHTML=inputvalue;
      var divbox=document.querySelector('.box');
      divbox.appendChild(newbox);

      document.querySelector('.text').value='';

 };
 function rem(){
    let list=document.querySelector('#commentbox');
    list.remove();
     
 };
 function edit1(){
      // let rename=e.parentElement.children[0].innerHTML;
      // var text=document.querySelector('.text');
      // text.value=rename;

      var name=document.getElementById('edit');
      var data=name.innerHTML;
      name.innerHTML="<input type='text' id='"+e+"' value='"+data+"'>";
 };
 function update1(u){
     let update1=u.parentElement.children[0];
      var text=document.querySelector('.text');
       upderHTML= text.value;ate1.inn
 };
 function hide(btn){
     btn.parentElement.parentElement.style.visibility='hidden';

 };


