

Day 1

    Predefined Tags
    Angular Brackets
    Root Tags
    How to run the HTML Program.

Extension 1 - How to run the HTML Program.

    Install Extenstion - Live Server
    Ctrl + Shift + P

Extensin 2 - How to Indent/Format the Program.

    Setting -> Format -> Find and enable the format on save options

    Head Tag

Tags have set of attributes

    But that is not mandatory
    id - Id should be unique
    name - Name will try to keep this also unique
    style - Styling
    class - Styling Common

Hard Working

    Vipul- Ajax
    Ritesh
    Leena
    Rahul - Media
    Pratik
    Aman - Callback
    CV based website.

Basic Rules of CSS

color:black; background:white;
Binding :: Link the CSS with HTML

css-property : property-value;
CSS can be applied in three different way

    Inline Styling -- It applies only to one element; (and its child elements).
    Internal Styling -- Clean Program -- This can be applied to multiple elements

Default things

color :black background: white; starts : top left; width: 100% (blocking elemnt) height: default height

Day 2

    Quick Revision
    CSS Basics Property [color, background, border, margin, padding, units, colors ]
    CSS Flex Box Detail

Most important tag of the Day 2

Most Important CSS Property

    color (foreground) -- COLOR_NAME -- rgb(200, 200, 200) -- rgba(50, 50, 50, 1) A is OPACITY here, the value can be (0, 1) -- hashcode (#4a8ad3)

    background

    border -- border width -- border style (solid/dotted) -- border color

    border-left

    border-right

    border-top

    border-bottom

    border-radius

    margin (If we want space BETWEEN element) -- margin-top -- mrging-bottom -- margin-left -- margin-right

    padding (Space WITHIN element) -- padding-top -- padding-bottm -- padding-left -- padding-right

Text Styling
    color
    font-size
    font-weight
    font-family
    text-align

Element Adjacent to Each other

    float : left;
    display: inline;

Related with flex

    diplay: flex; // Very Important
    justify-content : flex-start/center/flex-end/space-between :: Main Axis
    align-items :: Cross Axis