function compute() {
    var x = document.getElementById('num1').value;
    var y = document.getElementById('num2').value;
    var z = 0;
    if (document.getElementById('add')) {
        z = Number(x) + Number(y);
    }
    if (document.querySelector('#min')) {
        z = Number(x) - Number(y);
    }
    document.getElementById('a').value = z;
}