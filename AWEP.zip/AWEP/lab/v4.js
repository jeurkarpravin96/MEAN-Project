// var num = 3;
// function factor(num) {
//     let result = 1;
//     for (i = 0; i < num; i++) {
//         if (num > 0) {
//             result = result * num;
//             num--;
//         } else {
//             break;
//         }
//     }
//     console.log(result);
// }
// factor(num)


var num = 4;
console.log(Math.log(num));
