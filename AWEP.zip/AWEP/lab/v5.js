var countlike=0;
var count=0;
function increaselike(){
    let increaselike= document.querySelector('#b1');
    countlike++;
    if(countlike<=0){
       return; 
    }else{
        
        increaselike.innerHTML='<i class="fa fa-thumbs-o-up" aria-hidden="true">'+' '+countlike;
    } 
}

function dislike(){
    // let dislike= document.querySelector('#b2');
    // countlike--;
    // if(countdis<=0){
    //     return;
    // }else{
       
    //     dislike.innerHTML='<i class="fa fa-thumbs-o-down" aria-hidden="true">'+' '+countlike;
    // }

    let dislike= document.querySelector('#b2');
    count++;
    dislike.innerHTML='<i class="fa fa-thumbs-o-down" aria-hidden="true">'+' '+count;
}
function comment(){
    let comment=document.querySelector('#text').value;
    let clonevalue=document.querySelector('#commentbox').cloneNode(true);
    clonevalue.innerHTML=comment;
    let commentsDiv=document.querySelector('#commentbox'); //place kha kr raha wo dekh raha ye line pe 
    commentsDiv.insertBefore(clonevalue,commentsDiv.firstChild)//uska jo 1 child hai useke aage put kr raha
}
// function clear(){
//    let clear= document.querySelector('#text');
//    clear.value='';
// }