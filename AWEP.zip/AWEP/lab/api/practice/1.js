window.addEventListener=('load',()=>{
    console.log('n')
    let xhr= new XMLHttpRequest();
    xhr.open("GET","https://api.giphy.com/v1/gifs/search?api_key=VoCNEuX9m8lYf0FViUZLh8cNsCEBAal7&q=funny")
    xhr.onload=()=>{
        console.log(xhr.responseText)
    }
    xhr.send();
});