let readValue=()=>{
    const text1=document.querySelector('#text1').value;
         document.querySelector('#text1').value='';
         console.log(text1);
    const text2=document.querySelector('#text2').value;
         document.querySelector('#text2').value='';
         console.log(text2);
}