function readvalue() {
    console.log('function  working successefully');
    let username = document.querySelector('#username').value;
    if(username===""){
        document.querySelector('#username').innerHTML='plases enter comment';
        document.querySelector('#username').style.color='red';
    }else{
        document.querySelector('#commentbox').innerHTML = username;
        document.querySelector('#username').value ='';
        document.querySelector('#username').style.color='black';
    }
    
}


 