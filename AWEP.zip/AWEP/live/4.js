let readValue=()=>{
    const text1=document.querySelector('#text1').value;   
    const text2=document.querySelector('#text2').value; 
    let box=document.querySelector('.box');
         box.innerHTML=text1+' '+ "<br> "+text2;
         document.querySelector('#text1').value='';
         document.querySelector('#text2').value='';
}