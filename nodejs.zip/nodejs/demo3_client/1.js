let xhr=new XMLHttpRequest();
xhr.open('GET','http://localhost:5500/');
xhr.onload=()=>{
    let json=JSON.parse(xhr.responseText);
    console.log(json);
    dom(json);
}
xhr.send();

let dom=(json)=>{
    document.querySelector('.demo').innerHTML=json;
   // document.querySelector('.demo').style.visibility='visible';
}