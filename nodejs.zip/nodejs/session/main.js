const exprss=require('express');
const app=exprss();

const user=[];

app.get('/index',(req,res)=>{
    res.render('index.ejs',{name:req.body.name});
});

app.get('/log',(req,res)=>{
    res.render('log.ejs');
});


app.get('/register',(req,res)=>{
    res.render('register.ejs');
});


app.post('/register',(req,res)=>{
    try{
         
        user.push({
            name:req.body.name,
            email:req.body.email,
            password:req.body.password
        });
      res.render('log.ejs');
    }catch{
       res.render('register.ejs')
    }
});


app.post('/log',(req,res)=>{
    try{  
        user.push({
            username:req.body.username,
            password:req.body.password
        });
      res.render('index.ejs')
    }catch{
       res.render('register.ejs')
    }
});

app.listen(3001,()=>{
    console.log('server running on 3001 port')
})