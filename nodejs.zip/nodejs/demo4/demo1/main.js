
console.log('Entry points')