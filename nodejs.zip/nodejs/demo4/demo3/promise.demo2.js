const fs=require('fs');
const promise=require('bluebird');
promise.promisifyAll(fs);

let demo= async ()=>{
    const filepath='/home/pravin/awep/AWEP/nodejs/demo4/demo1/file.md';
    const data=await fs.readFileAsync(filepath,{encoding:'utf-8'});
    console.log('1',data);

    const filepath1='/home/pravin/awep/AWEP/nodejs/demo4/demo1/file1.md';
    const data1=await fs.readFileAsync(filepath1,{encoding:'utf-8'});
    console.log('2',data1);

    const filepath2='/home/pravin/awep/AWEP/nodejs/demo4/demo1/file2.md';
    const data2=await fs.readFileAsync(filepath2,{encoding:'utf-8'});
    console.log('3',data2);
}
demo();
console.log('asynchronous function');
console.log('asynchronous function 1');