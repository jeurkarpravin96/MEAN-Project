const fs=require('fs');
const promise=require("bluebird");

// promisification :: converts all the callback methods and return as Promise
promise.promisifyAll(fs);

let demo=()=>{
   const filepath='/home/pravin/awep/AWEP/nodejs/demo4/demo1/file.md';

   // Promise
  const mpromise= fs.readFileAsync(filepath,{encoding:'utf-8'});
  
  //success
  mpromise.then((data)=>{
      console.log(data);
  });

  //failure
  mpromise.catch((err)=>{
    console.log('Some problem',err);
});
}
demo();