const fs = require('fs');
const promise = require('bluebird');
const { captureRejectionSymbol } = require('events');
promise.promisifyAll(fs);


let demo = () => {
    const filepath = '/home/pravin/awep/AWEP/nodejs/demo4/demo1/file.md';
    //absolute path means path which start with '/'
    //Relative paths do not start with '/' 
    const data = fs.readFileAsync(filepath, { encoding: 'utf-8' })
        .then((data) => {
            console.log('[1]', data);
            const filepath1 = '/home/pravin/awep/AWEP/nodejs/demo4/demo1/file1.md';
            return fs.readFileAsync(filepath1, { encoding: 'utf-8' });
        })
        .then((data) => {
            console.log('[2]',data);
        })
        .catch((err) => {
            console.log('error',data);
        })
};
demo();