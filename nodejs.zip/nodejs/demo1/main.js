let cal=require('./1')
cal.add(10,20);
console.log('Here you will get all type of calcultion',cal.div(10,20));
console.log(cal);