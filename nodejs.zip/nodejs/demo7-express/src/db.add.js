const Promise=require('bluebird');
const mysql=require('mysql');
const config=require('./config');

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);


let addData=async(fname,lname)=>{
 try{
    const Connection=   mysql.createConnection(config.DB_Config);

    await Connection.connectAsync();
    //logic section
    let sql='insert into user (fname,lname) values(?,?)';
    await Connection.queryAsync(sql,[fname,lname]);
    
    await Connection.endAsync();
 }catch(err){
     console.log('error');
 }

}


module.exports={addData};