 
 const express=require('express');
 const app=express();

 const read=require('./db.read');
 const add=require('./db.add');
 app.get('/',async(req,res)=>{
      
       try{
        let user={msg:'success'};
        const data=await read.readAlldata();
        res.json(data);
       }catch(err){
         let user={msg:'failure'}
         res.json(user);
       }
      
 });
 //app.get('/search')

 app.get('/search',(req,res)=>{
      try{
        let daeta={id:'1',fname:'pravin',lname:'jeurkar'};
        res.json(data);
      }catch(err){
         let data={msg:'fails'};
         res.json(data);
      }
 });

 app.get('/user',async(req,res)=>{
     try{
      let fname=req.query.fname;
      let lname=req.query.lname;
     await add.addData(fname,lname);
     let obj={msg:'success'}
       res.json(obj);
     }catch(err){
       let obj={msg:'fails'}
       res.json(obj);
     }
 });

 app.listen(5000);