const mysql=require('mysql');
const mod=require('./main');


let dataread= async()=>{
   const connection= mysql.createConnection(mod.DB_Connection);


   connection.connectAsync();
   let sql='delete from user where id=?';
   let data= connection.queryAsync(sql,['1']);
   
   console.log(data);
   connection.endAsync();
}
dataread();