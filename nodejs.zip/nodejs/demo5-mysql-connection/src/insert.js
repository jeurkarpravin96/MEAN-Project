const Promise = require('bluebird');
const mysql = require('mysql');

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const database = {
    host: 'localhost',
    user: 'root',
    password: 'Pravin@123',
    database: 'mydb'
};

let readDatabaseData = async () => {
    const Connection = mysql.createConnection(database);

    await Connection.connectAsync();
    //to insert multiple values
    // let sql = 'insert into user (fname,lname,mobileNo) values(?,?,?),(?,?,?)';
    // let data = await Connection.queryAsync(sql,['gaurav','nawale','7350761904','vaibhav','nawale','123456789']); 
    

    //another way
    // let sql = 'insert into user (??,??,??) values(?,?,?),(?,?,?)';
    // let data = await Connection.queryAsync(sql,['fname','lname','mobileNo','gaurav','nawale','7350761904','vaibhav','nawale','123456789']); 
  
    let sql = 'insert into ?? (??,??,??) values(?,?,?),(?,?,?)';
    let data = await Connection.queryAsync(sql,['user','fname','lname','mobileNo','gaurav','nawale','7350761904','vaibhav','nawale','123456789']); 
    console.log(data);

    await Connection.endAsync();
};

readDatabaseData();