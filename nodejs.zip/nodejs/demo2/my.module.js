let arr=[
    {id:1,fname:'pravin',lname:'jeurkar'},
    {id:2,fname:'ritesh',lname:'garud'},
    {id:3,fname:'priyanka',lname:'soni'}
];




class add{
    constructor(...no_of_argument){ //vargar method
      //  console.log(no_of_argument)
        this.arg=[];
        if(no_of_argument.length>0){
            for(let i=0;i<no_of_argument.length;i++){
                this.arg[i]=no_of_argument[i];
            }
        }
    }
   getdetails(){
      return this.arg;
   }
}

// let addition= new add('pravin',1,2,3,4,5,6,'jeurkar');
// //console.log(addition.getdetails());
// let p=addition.getdetails();

// module.exports={
//     arr,
//     p
// };


module.exports=add;