let list={
    fname:'pravin',
    lname:'jeurkar',
    age:25
};

module.exports=list;