let mod=require('./2')
let http=require('http');
http.createServer((request,response)=>{
    response.setHeader("Access-Control-Allow-Origin",'*')
     // let p=JSON.stringify(mod);
       response.end(JSON.stringify(mod));
}).listen(5500,()=>{
console.log('your project is run on 5500 port');
});