const Promise= require('bluebird');
const mysql=require('mysql');



Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const config=require('./config');

let demo=async()=>{
   const Connection=   mysql.createConnection(config.DB_Config);

  await Connection.connectAsync();
  let sql='select * from user'
  const data=await  Connection.queryAsync(sql);

  await Connection.endAsync();

  return data

}