const Promise=require('bluebird');
const mysql=require('mysql');

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const config=require('./config');
/**
 * 
 * @param {*} user 
 */

let deletedatajson=async(input)=>{
   const  Connection=mysql.createConnection(config.DB_Config);
   await Connection.connectAsync();

  let sql='delete from user where id=? and fname=?'
  const data=  Connection.queryAsync(sql,[input.id,input.fname])
   await Connection.endAsync();
   return data;
};

module.exports={deletedatajson}