
const Promise=require('bluebird');
const mysql=require('mysql');
const config=require('./config');

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

let dbupdatedata=async(user)=>{
     const Connection=  mysql.createConnection(config.DB_Config);

    await Connection.connectAsync();
    let sql='update user set mobileNo=? where fname=?'
    let data=await Connection.queryAsync(sql,[user.mobileNo,user.fname]);
    await Connection.endAsync();
    return data;
};


module.exports={dbupdatedata};