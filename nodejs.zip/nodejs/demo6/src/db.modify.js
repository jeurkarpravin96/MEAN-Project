const Promise=require('bluebird');
const mysql=require('mysql');
const config=require('./config');

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

let dbmodifydata=async(user)=>{
  const Connection= mysql.createConnection(config.DB_Config);
  await Connection.connectAsync();

  let sql='alter table user modify COLUMN ?? varchar(20);';
  const data=await Connection.queryAsync(sql,[user.column]);

  await Connection.endAsync();
  return data;
};

module.exports={dbmodifydata}

