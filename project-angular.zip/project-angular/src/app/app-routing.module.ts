import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { HomeComponent } from './home/home.component';
import { ErrorComponent } from './error/error.component';
import { TravelOffersComponent } from './travel-offers/travel-offers.component';
import { FlightComponent } from './flight/flight.component';
import { BookComponent } from './book/book.component';
import { ForgetComponent } from './forget/forget.component';


const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'flight',component:FlightComponent},
  {path:'offer',component:TravelOffersComponent},
  {path:'login',component:LoginComponent},
  {path:'signup',component:SignupComponent},
  
  { path:'', redirectTo: '/login', pathMatch: 'full' },
   {path:'forget',component:ForgetComponent},
  { path: '**', component:ErrorComponent},
   {path:'book',component:BookComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
