import { Component, OnInit } from '@angular/core';

import{faPlaneDeparture} from '@fortawesome/free-solid-svg-icons'
import{faBuilding} from '@fortawesome/free-solid-svg-icons'
import{faTrain} from'@fortawesome/free-solid-svg-icons';
import{faTimesCircle} from '@fortawesome/free-solid-svg-icons';
import{faBus} from '@fortawesome/free-solid-svg-icons';

import { Router } from '@angular/router';

@Component({

  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
  public faPlaneDeparture=faPlaneDeparture;
  public faBuilding=faBuilding;
  public faTrain=faTrain;
  public faTimesCircle=faTimesCircle;
  public faBus=faBus;


  constructor(private router:Router) { }
 

  list:any=[
    {title:'Fights',icon:'faPlaneDeparture'},
    {title:'Hotels',icon:'faBuilding'},
    {title:'Trains',icon:'faTrain'}
  ];

 

  arr:any=[
    {url:'assets/1.jpeg',title:' Gift Cards'},
    {url:'assets/2.jpg',title:' Meal & Deals'},
    {url:'assets/2.webp',title:' Travel Offers',nav:'login'}
  ];

  ngOnInit(): void {
  
  }

  

};