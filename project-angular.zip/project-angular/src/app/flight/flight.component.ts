import { Component, OnInit } from '@angular/core';
import{faArrowLeft} from '@fortawesome/free-solid-svg-icons'
import{faPlaneDeparture} from '@fortawesome/free-solid-svg-icons';
import{faPlaneArrival} from '@fortawesome/free-solid-svg-icons'
import{faBuilding} from '@fortawesome/free-solid-svg-icons'
import{faTrain} from'@fortawesome/free-solid-svg-icons';
import{faBus} from '@fortawesome/free-solid-svg-icons';
import{faHome} from '@fortawesome/free-solid-svg-icons'
import{faBriefcase} from '@fortawesome/free-solid-svg-icons';
import{faUser} from '@fortawesome/free-solid-svg-icons';
import { FormControl,FormGroup } from '@angular/forms';
import { NgForOf } from '@angular/common';
import{faPlane} from '@fortawesome/free-solid-svg-icons'

@Component({
  selector: 'app-flight',
  templateUrl: './flight.component.html',
  styleUrls: ['./flight.component.css']
})
export class FlightComponent implements OnInit {

 public faArrowLeft=faArrowLeft;
 public faPlaneArrival=faPlaneArrival;
 public faPlaneDeparture=faPlaneDeparture;
 public faBuilding=faBuilding;
 public faTrain=faTrain;
 public faBus=faBus;
 public faHome=faHome;
 public faBriefcase=faBriefcase;
 public faUser=faUser;
 public faPlane=faPlane;


  constructor() { }

  ngOnInit(): void {
  }

  flightList:any=[

    {
    flightname:'airline',
    price:'₹5000',
    source:{s:'pune',sdepart:'23/10/2020',time:'12:00 AM'},
    destination:{des:'delhi',sdepart:'23/10/2020',time:'14:00 PM'},
    mid_destination:{smid:'mumbai',sdepart:'23/10/2020',time:'15:50 PM'}
    },
    
    
    {
    flightname:'airbiz',
    price:'₹6000',
    source:{s:'mumbai',sdepart:'20/10/2020',time:'01:00 AM'},
    destination:{des:'panaji',sdepart:'20/10/2020',time:'02:45 AM'},
    mid_destination:{smid:'chennai',sdepart:'20/10/2020',time:'04:00 AM'}
    },
    
    
    
    {
    flightname:'nicejet',
    price:'₹8000',
    source:{s:'pune',sdepart:'25/10/2020',time:'04:00 PM'},
    destination:{des:'mumbai',sdepart:'25/10/2020',time:'05:00 PM'},
    mid_destination:{smid:'hyderabad',sdepart:'25/10/2020',time:'06:50 PM'}
    },
    
    
    {
    flightname:'airways',
    price:'₹8000',
    source:{s:'delhi',sdepart:'22/10/2020',time:'14:00 AM'},
    destination:{des:'mumbai',sdepart:'22/10/2020',time:'15:10 AM'},
    mid_destination:{smid:'bangalore',sdepart:'22/10/2020',time:'17:30 AM'}
    },

    {

    flightname:'airline',
    price:'₹4500',
    source:{s:'pune',sdepart:'25/10/2020',time:'04:00 PM'},
    destination:{des:'mumbai',sdepart:'25/10/2020',time:'05:00 PM'},
    mid_destination:{smid:'hyderabad',sdepart:'25/10/2020',time:'06:50 PM'}
    },

    {
    flightname:'airways',
    price:'₹5500',
    source:{s:'pune',sdepart:'25/10/2020',time:'04:00 PM'},
    destination:{des:'mumbai',sdepart:'25/10/2020',time:'05:00 PM'},
    mid_destination:{smid:'hyderabad',sdepart:'25/10/2020',time:'06:50 PM'}
    },
    
    ];

    myform=new FormGroup({
      from:new FormControl(''),
      datato:new FormControl('')
    }); 

 
arr=[1];
searchData(){
      console.log(this.myform.value);
  for (let obj of this.flightList ) {
        // console.log(obj);
        const arr=[];
        const from=this.myform.value.from.toLowerCase();
        const datato=this.myform.value.datato.toLowerCase();
        
        const source=obj.source.s;
        const destination=obj.destination.des;
        
          
          if(source===from && destination===datato){
            arr.push[1];
            console.log('success')
            this.flightname=obj.flightname;
            this.source=obj.source.s;
            this.destination=obj.destination.des;
            this.mid_destination=obj.mid_destination.smid;
            this.price=obj.price;
            this.time=obj.source.time;
            this.time1=obj.destination.time;
            this.time2=obj.mid_destination.time;
           }
      }
    }

       flightname:string;
       source:string;
       destination:string;
       mid_destination:string;
       time:any;
       price:any;  
       time1:any;
       time2:any;
  public flight="FLIGHTNAME"
  public arrow='---->'
  public DESTINATION='DESTINATION';
  public source1='SOURCE';
}
