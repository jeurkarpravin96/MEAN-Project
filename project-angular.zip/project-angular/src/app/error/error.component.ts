import { Component, OnInit } from '@angular/core';
import{faFrown} from '@fortawesome/free-solid-svg-icons'
import{faArrowLeft} from'@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.css']
})
export class ErrorComponent implements OnInit {
  
  public faFrown=faFrown;
  public faArrowLeft=faArrowLeft;

  constructor() { }

  ngOnInit(): void {
  }

}
