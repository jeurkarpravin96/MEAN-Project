import { Component, OnInit } from '@angular/core';
import{faArrowLeft} from '@fortawesome/free-solid-svg-icons';
import{FormBuilder,Validators} from '@angular/forms'
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
@Component({
  selector: 'app-forget',
  templateUrl: './forget.component.html',
  styleUrls: ['./forget.component.css']
})
export class ForgetComponent implements OnInit {

  constructor(private fb:FormBuilder,private http:HttpClient,private router:Router ){ }

  ngOnInit(): void {
  }
  public faArrowLeft=faArrowLeft;

  public fbFormGroup = this.fb.group({
    email: ['', [Validators.required,Validators.email]],
    password: ['',[ Validators.required,Validators.minLength(5),Validators.maxLength(10)]],
  });

public updatedata=false;
public dataupdate=false;
  async updatepassword(){
    try{
   
    console.log('running')
    const data = this.fbFormGroup.value;
    const url = 'http://localhost:5001/update';
    const result:any =await this.http.post(url, data).toPromise();
    this.updatedata= true;
    console.log(data);
    this.fbFormGroup.reset();
    
    }catch(err){
      this.dataupdate=true;
      }
     
    }
  }

