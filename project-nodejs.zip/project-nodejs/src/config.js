const DB_Config={
    host:'localhost',
    user:'root',
    password:'Pravin@123',
    database:'project'
};

module.exports={DB_Config}