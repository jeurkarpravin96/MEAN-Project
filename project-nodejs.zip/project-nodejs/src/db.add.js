const Promise=require('bluebird');
const mysql=require('mysql');
const config=require('./config');

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);



let adduser = async (input) => {
    const connection = mysql.createConnection(config.DB_Config);
    await connection.connectAsync();
  
    let sql='insert into signup (fname,lname,mobile,email,password) values(?,?,?,?,?)';
    await connection.queryAsync(sql, [
      input.fname,
      input.fname,
      input.mobile,
      input.email,
      input.password,
    ]);
  
    await connection.endAsync();
  };

//  let auth={
//      email:'333',
//      password:'eee'
//  }


let authuser= async(authuser)=>{
    try{
        const Connection=   mysql.createConnection(config.DB_Config);
    
        await Connection.connectAsync();
        //logic section
        let sql='select * from signup where email=? and password=?';
       let result= await Connection.queryAsync(sql,[authuser.email,authuser.password]);
       
        await Connection.endAsync();

        return result;

     }catch(err){
         console.log(err);
     }
}

let updatepassword= async(update)=>{
  try{
      const Connection=   mysql.createConnection(config.DB_Config);
  
      await Connection.connectAsync();
      //logic section
      let sql='update signup set password=? where email=?';

     let result1= await Connection.queryAsync(sql,[update.password,update.email]);
     
      await Connection.endAsync();

      return result1;

   }catch(err){
       return false;
   }
}

module.exports={adduser,authuser,updatepassword};
