const express=require('express');
var cors = require('cors')
var app = express();

app.use(cors());
app.use(express.json())
const add=require('./db.add');


//http://localhost:5000/adduser

app.post("/add", async (req, res) => {
  try{
      const input = req.body;

      
      await add.adduser(input);
      
      //res.json({output: input});

  } catch(err){
      res.json({message: "failed"});
  }
});

app.get('/user',(req,res)=>{
  res.json('success');
});


app.post("/auth",async(req,res)=>{
  
      const auth=req.body;
     let data= await add.authuser(auth);
  
     if(data.length==0){
      res.json({operation:false});
      }else
        res.json({operation:true});
      
});


app.post("/update",async(req,res)=>{
  
  const auth=req.body;
 let data1= await add.updatepassword(auth);

 return data1;

 
  
});



app.listen(5001);