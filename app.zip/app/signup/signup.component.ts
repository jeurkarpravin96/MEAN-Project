import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators,FormControl,FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Route } from '@angular/compiler/src/core';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {



  constructor(private fb: FormBuilder,private router:Router,private http:HttpClient) {}

  
  public fbFormGroup = this.fb.group({
    fname: ['', [Validators.required]],//pattern regex it is frame work angular
    lname: ['', [Validators.required]],
    email: ['', [Validators.required,Validators.email]],
    mobile: ['', [Validators.required]],
    password: ['',[ Validators.required,Validators.minLength(5),Validators.maxLength(10)]],
    cpassword: ['',[ Validators.required,Validators.minLength(5),Validators.maxLength(10)]]
  });

//for checking invalid or not
  get fname(){return this.fbFormGroup.get('fname') } ;
  get lname(){return this.fbFormGroup.get('lname') };
  get email(){return this.fbFormGroup.get('email') };
  get mobile(){return this.fbFormGroup.get('mobile') }; 
  get password(){return this.fbFormGroup.get('password') }; 
  get cpassword(){return this.fbFormGroup.get('cpassword') }; 

  public name=this.fbFormGroup.value.fname +''+this.fbFormGroup.value.lname;
 
  

  ngOnInit(): void {
  }

  register = false;


  async registerhere(){
    console.log(this.name)
    this.register = true;
    const data = this.fbFormGroup.value;
    //console.log(data);
      if(data.password===data.cpassword && !data.invalid){
        const url = 'http://localhost:5001/add';
        await this.http.post(url, data).toPromise();
     
      }
  }
}