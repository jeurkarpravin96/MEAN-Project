import { Component, OnInit } from '@angular/core';
import{FormBuilder,Validators} from '@angular/forms'
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private fb:FormBuilder,private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  }
 
  public fbFormGroup = this.fb.group({
    email: ['', Validators.required],
    password: ['', Validators.required]
  });


  public usernotyetlogin = false;



  async loginuser(){

    console.log('running')
    const data = this.fbFormGroup.value;
    const url = 'http://localhost:5001/auth';
    const result:any =await this.http.post(url, data).toPromise();
    console.log(data);

    if(result && result.operation){
      
      sessionStorage.setItem('sid','true');
      this.router.navigate(['home']);
      this.fbFormGroup.reset();
    }else{
      this.usernotyetlogin = true;
    }
  }
}
