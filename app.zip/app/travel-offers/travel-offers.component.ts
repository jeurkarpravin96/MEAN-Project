import { Component, OnInit } from '@angular/core';
import{faPlaneDeparture} from '@fortawesome/free-solid-svg-icons'
import{faBuilding} from '@fortawesome/free-solid-svg-icons'
import{faTrain} from'@fortawesome/free-solid-svg-icons';
import{faBus} from '@fortawesome/free-solid-svg-icons';


@Component({
  selector: 'app-travel-offers',
  templateUrl: './travel-offers.component.html',
  styleUrls: ['./travel-offers.component.css']
})
export class TravelOffersComponent implements OnInit {
  public faPlaneDeparture=faPlaneDeparture;
  public faBuilding=faBuilding;
  public faTrain=faTrain;
  public faBus=faBus;
  constructor() { }

  ngOnInit(): void {
  }

}
